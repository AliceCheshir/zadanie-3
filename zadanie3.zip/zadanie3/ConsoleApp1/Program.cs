﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите строку: ");
        string input = Console.ReadLine();

        bool isValid = CheckIfValid(input);

        if (!isValid)
        {
            Console.WriteLine("Ошибка! В строке введены неподходящие символы.");

            // выводим список неподходящих символов
            Console.Write("Неподходящие символы: ");
            foreach (char c in input)
            {
                if (!Char.IsLower(c) || !Char.IsLetter(c)) // проверяем, является ли символ буквой в нижнем регистре
                {
                    Console.Write(c + " ");
                }
            }

            Console.WriteLine();
        }
        else // если введенная строка подходит
        {
            string result = "";

            if (input.Length % 2 == 0) // если строка четная
            {
                int mid = input.Length / 2;
                string firstHalf = input.Substring(0, mid);
                string secondHalf = input.Substring(mid);

                string reversedFirstHalf = ReverseString(firstHalf);
                string reversedSecondHalf = ReverseString(secondHalf);

                result = reversedFirstHalf + reversedSecondHalf;
            }
            else // если строка нечетная
            {
                string reversedInput = ReverseString(input);
                result = reversedInput + input;
            }

            Console.WriteLine($"Обработанная строка: {result}");

            // подсчитываем количество повторений каждого символа
            Dictionary<char, int> charCount = new Dictionary<char, int>();
            foreach (char c in result)
            {
                if (charCount.ContainsKey(c))
                {
                    charCount[c]++;
                }
                else
                {
                    charCount[c] = 1;
                }
            }

            // выводим информацию о количестве повторений каждого символа
            Console.WriteLine("Количество повторений каждого символа:");
            foreach (KeyValuePair<char, int> pair in charCount)
            {
                Console.WriteLine($"Символ {pair.Key}: {pair.Value} раз(а)");
            }
        }
    }

    static string ReverseString(string str)
    {
        char[] charArray = str.ToCharArray();
        Array.Reverse(charArray);
        return new string(charArray);
    }

    static bool CheckIfValid(string str)
    {
        foreach (char c in str)
        {
            if (!Char.IsLower(c) || !Char.IsLetter(c)) // проверяем, является ли символ буквой в нижнем регистре
            {
                return false; // если есть неподходящий символ, возвращаем false
            }
        }

        return true; // если все символы подходят, возвращаем true
    }
}